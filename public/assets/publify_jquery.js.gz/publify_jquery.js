$(document).ready(function() {
   $(function() {
    $( ".datepicker" ).datepicker();
   });
});
